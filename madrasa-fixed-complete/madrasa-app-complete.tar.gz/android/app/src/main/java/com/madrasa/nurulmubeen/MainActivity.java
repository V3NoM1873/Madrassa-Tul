package com.madrasa.nurulmubeen;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
