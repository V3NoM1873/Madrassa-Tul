import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.madrasa.nurulmubeen',
  appName: 'Madrasa tul Nurul Mubeen',
  webDir: 'out'
};

export default config;
